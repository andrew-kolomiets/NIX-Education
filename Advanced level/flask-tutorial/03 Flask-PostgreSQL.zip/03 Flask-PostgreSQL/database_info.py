
class database_info():
    database="testdb"
    user="pgadmin"
    host="127.0.0.1"
    password="secure_password"